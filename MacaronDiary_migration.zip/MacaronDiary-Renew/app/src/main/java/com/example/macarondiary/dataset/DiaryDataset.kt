package com.example.macarondiary.dataset

class DiaryDataset(
    var diary_title: String,
    var diary_shopname: String,
    var diary_date: String,
    var diary_content: String,
    var diary_imagepath: String
)



