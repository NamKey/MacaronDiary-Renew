package com.example.macarondiary.retrofitdataset

 class ResponseDiary(var review_id:Int
                     ,var user_id:String
                     , var review_imagepath:String
                     , var review_date:String
                     , var review_shopname:String
                     , var review_diarycontent:String)