# MacaronDiary-Renew
 MacaronDiary new Design/Kotlin
 
 Server : Nginx
 wsgi : uwsgi
 WebFramework : Django
 port : 8080 
